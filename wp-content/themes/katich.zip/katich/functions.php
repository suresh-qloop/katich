<?php

register_nav_menus(
    array('primary-menu' => 'Header Menu')
);


add_theme_support('post-thumbnails');
add_theme_support('custom-header');


add_action( 'init', 'create_custom_post' );
function create_custom_post() {
    $args = array(
        'public' => true,
        'label'  => 'Slider',
        'menu_icon' => 'dashicons-images-alt',
        'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ), 
    );
    register_post_type( 'custom_post', $args );
}

?>