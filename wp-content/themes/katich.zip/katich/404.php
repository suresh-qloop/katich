<?php

get_header();
wp_head();

?>

    <div class="pagenot" style="font-size: 50px; padding: 40px 0px 20px 0px; text-align:center;">Error 404 not Found</div>

<?php

get_footer();

?>