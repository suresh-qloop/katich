<?php

wp_head();
get_header();
the_post();

?>



<?php

wp_footer();
get_footer();

?>