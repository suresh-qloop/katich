<?php

get_header();
wp_head();

?>


<?php

wp_footer();
get_footer();

?>