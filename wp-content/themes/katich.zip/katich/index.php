<?php

// Silente is golden