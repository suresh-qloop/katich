<?php

// Silente is golden

?>

